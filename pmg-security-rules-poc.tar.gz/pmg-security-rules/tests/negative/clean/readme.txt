This directory contains general documentation for the internal wiki export.
No sensitive or executable content is present.
