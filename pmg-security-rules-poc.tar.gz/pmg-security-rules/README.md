# PMG + ClamAV + YARA — CI/CD PoC

This is a working proof-of-concept implementing the design in
`Proxmox Mail Gateway + ClamAV + YARA CI/CD Pipeline` (v1.0, 2026-08-26).
Everything here has been executed and verified (ClamAV 1.5.3, YARA 4.5.0 on
Debian/Ubuntu) — not just written from the spec.

## What's in the box

```
pmg-security-rules/
├── yara/malware/company_malware_test.yar   # PoC rule (synthetic, safe strings)
├── tests/positive/company_malware_test/    # 2 synthetic "malicious" samples
├── tests/negative/clean/                   # clean invoice/notes/readme + a zip
├── tests/eicar/eicar.com                   # standard EICAR AV test string
├── scripts/
│   ├── test-yara.sh          # Stage 1: YARA syntax validation
│   ├── test-clamav-load.sh   # Stage 2: ClamAV loads the rule DB
│   ├── test-positive.sh      # Stage 3: malicious samples MUST be detected
│   ├── test-negative.sh      # Stage 4: clean samples MUST NOT be detected
│   ├── test-eicar.sh         # Stage: EICAR sanity check (needs freshclam)
│   ├── package-rules.sh      # Builds versioned tar.gz + sha256
│   └── build-test-email.sh   # Builds real .eml files for PMG injection
├── Makefile
└── .gitlab-ci.yml
```

## What was actually verified in this session

1. `company_malware_test.yar` passes YARA syntax validation (`yara --fail-on-warnings`).
2. ClamAV 1.5.3 loads the rule and reports `YARA.COMPANY_MALWARE_TEST.UNOFFICIAL FOUND`
   on both positive samples.
3. **Important gotcha discovered:** `clamscan --database=<dir>` does **not** recurse
   into subdirectories. If your `yara/` tree has rules nested under `yara/malware/`,
   `yara/attachment/`, etc. (as the design doc's repo layout recommends), ClamAV will
   silently fail to find any rules (`cli_loaddbdir: No supported database files found`).
   All scripts here flatten the rule tree into a temp directory before calling
   `clamscan` — do this in your real deploy step too, or ClamAV will load an empty DB.
4. All 4 clean negative samples (txt files + a zip) pass with `OK` — no false positives.
5. A full `.eml` MIME message (base64 attachment, multipart) built with
   `build-test-email.sh` was scanned directly with ClamAV and still triggered
   correctly — confirming detection survives MIME/base64 wrapping, which is what
   PMG actually sees on the wire.
6. Packaging produces a versioned `yara-rules-<version>.tar.gz` + `.sha256`.

**Not verified here (needs your real PMG VM):**
- EICAR test — my sandbox's egress proxy blocks `database.clamav.net`, so
  `freshclam` can't pull the official signature DB. Your PMG VM has normal
  internet access, so `make eicar` (or `scripts/test-eicar.sh`) should just work there.
- Actual PMG mail-flow injection and quarantine behavior — see below.

## Running it locally (dev machine or CI runner)

```bash
make lint          # YARA syntax
make clamav-load    # ClamAV can load the rule DB
make positive        # malicious samples detected
make negative         # clean samples NOT detected
make eicar             # needs freshclam DB populated first
make package             # -> dist/yara-rules-<version>.tar.gz + .sha256
```

## Testing against your PMG staging VM

1. **Deploy the rule to PMG's ClamAV custom-signature directory** — commonly
   `/var/lib/clamav-custom/` on PMG, referenced from `clamd.conf` via an
   additional `DatabaseDirectory` or symlinked into ClamAV's db path (exact
   path depends on your PMG version — check `clamd.conf` / PMG's antivirus
   config). Remember: **flatten to one directory**, no subfolders.

   ```bash
   scp dist/yara-rules-*.tar.gz root@pmg-staging:/tmp/
   ssh root@pmg-staging
   tar xzf /tmp/yara-rules-*.tar.gz -C /var/lib/clamav-custom/
   systemctl reload clamav-daemon   # or the PMG-specific equivalent
   ```

2. **Build test emails and inject them into the real mail path:**

   ```bash
   ./scripts/build-test-email.sh dist/test-emails
   scp dist/test-emails/*.eml root@pmg-staging:/tmp/
   ssh root@pmg-staging
   sendmail test-recipient@yourtestdomain < /tmp/malicious-test.eml
   sendmail test-recipient@yourtestdomain < /tmp/eicar-test.eml
   sendmail test-recipient@yourtestdomain < /tmp/clean-test.eml
   ```

3. **Check results:**
   - PMG web UI → Administration → Quarantine → Virus/Malware Quarantine
   - `tail -f /var/log/mail.log` (or `journalctl -u pmg-smtp-filter -f`)
   - Expect: `malicious-test.eml` and `eicar-test.eml` quarantined,
     `clean-test.eml` delivered.

## Notes / things to adapt before production

- The rule and samples here are **entirely synthetic** — safe placeholder
  strings (`COMPANY-MALWARE-TEST`, `MALWARE-PAYLOAD`), no real malware. Real
  detection rules will need real (safely handled, access-restricted) malware
  samples per section 9 of the design doc.
- `RULE_DIR` flattening logic in the scripts should be mirrored in whatever
  your actual PMG deployment/reload script does — don't just `tar xzf` a
  nested tree onto PMG and assume it'll work.
- EICAR requires ClamAV's official signature DB (`freshclam`) to be current
  on PMG — this is separate from your custom YARA DB.
