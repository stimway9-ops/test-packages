#!/bin/bash
# Stage: Positive detection tests
# Every sample under tests/positive/ MUST be detected by ClamAV using the custom YARA database.
set -euo pipefail

SRC_DIR="${1:-./yara}"
POS_DIR="${2:-./tests/positive}"

# ClamAV's --database loader does NOT recurse into subdirectories, so flatten
# the (possibly nested) yara/ source tree into a single dir before loading.
RULE_DIR="$(mktemp -d)"
find "$SRC_DIR" -type f \( -name '*.yar' -o -name '*.yara' \) -exec cp {} "$RULE_DIR/" \;

echo "=== Positive detection tests (database: $RULE_DIR, flattened from $SRC_DIR) ==="
find "$POS_DIR" -type f | while read -r file; do
    echo "Testing (expect DETECT): $file"
    # clamscan exits 1 when a match is FOUND (that's success for a positive test),
    # so capture output/status separately rather than relying on pipeline exit code.
    output=$(clamscan --database="$RULE_DIR" --no-summary "$file" || true)
    echo "$output"
    if echo "$output" | grep -q "FOUND"; then
        echo "  PASS: detected"
    else
        echo "  FAIL: expected detection did not occur"
        exit 1
    fi
done

echo "All positive tests passed."
