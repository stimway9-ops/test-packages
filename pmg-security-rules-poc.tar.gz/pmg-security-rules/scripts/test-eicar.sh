#!/bin/bash
# Stage: EICAR test
# Confirms the ClamAV engine itself is functioning, independent of custom YARA logic.
# Uses the standard, harmless EICAR antivirus test string - not real malware.
set -euo pipefail

EICAR_FILE="${1:-./tests/eicar/eicar.com}"

echo "=== EICAR pipeline test ==="
# EICAR detection relies on ClamAV's built-in signature DB (freshclam), separate from our custom YARA DB.
result=$(clamscan --no-summary "$EICAR_FILE" || true)
echo "$result"
if echo "$result" | grep -qi "eicar"; then
    echo "PASS: ClamAV engine detected EICAR."
else
    echo "FAIL or SKIPPED: ClamAV signature DB (freshclam) may not be populated yet in this environment."
    echo "Run 'freshclam' to download the official virus database, then retry."
    exit 1
fi
