#!/bin/bash
# Stage 1: YARA syntax validation (standalone compiler, not ClamAV yet)
set -euo pipefail

RULE_DIR="${1:-./yara}"
SAMPLE="${2:-./tests/positive/company_malware_test/sample01.bin}"

echo "=== YARA syntax validation ==="
find "$RULE_DIR" -type f \( -name '*.yar' -o -name '*.yara' \) -print0 |
while IFS= read -r -d '' rule
do
    echo "Testing: $rule"
    yara --fail-on-warnings "$rule" "$SAMPLE" >/dev/null
    echo "  -> syntax OK"
done
echo "All rules passed syntax validation."
