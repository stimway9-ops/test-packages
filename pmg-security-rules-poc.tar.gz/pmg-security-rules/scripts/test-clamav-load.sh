#!/bin/bash
# Stage 2: ClamAV compatibility test.
# ClamAV's YARA support is a subset of full YARA (e.g. no "import" modules like
# pe/hash/math). This confirms the production scanning engine actually loads
# the rule set without errors, independent of whether it matches anything yet.
set -euo pipefail

SRC_DIR="${1:-./yara}"
RULE_DIR="$(mktemp -d)"
find "$SRC_DIR" -type f \( -name '*.yar' -o -name '*.yara' \) -exec cp {} "$RULE_DIR/" \;

echo "=== ClamAV database load test (flattened: $RULE_DIR) ==="
# Scan something empty/harmless just to force ClamAV to load the DB and report load errors.
tmp_probe="$(mktemp)"
echo "probe" > "$tmp_probe"

output=$(clamscan --database="$RULE_DIR" --no-summary "$tmp_probe" 2>&1 || true)
echo "$output"

if echo "$output" | grep -qi "cli_loaddbdir\|Can't open file or directory\|LibClamAV Error"; then
    echo "FAIL: ClamAV rejected or could not load the rule database."
    exit 1
fi

echo "PASS: ClamAV loaded the custom YARA database successfully."
