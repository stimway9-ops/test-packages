#!/bin/bash
# Package approved YARA rules into a versioned, checksummed artifact.
# The artifact contains a FLAT directory of .yar files, matching what
# clamscan --database=<dir> actually requires (no recursive subdirs).
set -euo pipefail

SRC_DIR="${1:-./yara}"
VERSION="${VERSION:-$(date +%Y.%m.%d)-001}"
OUT_DIR="${2:-./dist}"

mkdir -p "$OUT_DIR"
STAGE="$(mktemp -d)"
find "$SRC_DIR" -type f \( -name '*.yar' -o -name '*.yara' \) -exec cp {} "$STAGE/" \;

tarball="$OUT_DIR/yara-rules-${VERSION}.tar.gz"
tar -C "$STAGE" -czf "$tarball" .
sha256sum "$tarball" > "${tarball}.sha256"

echo "Packaged: $tarball"
echo "Checksum: ${tarball}.sha256"
cat "${tarball}.sha256"
