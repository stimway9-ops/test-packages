#!/bin/bash
# Stage: Negative / false-positive tests
# No sample under tests/negative/ may EVER be detected.
set -euo pipefail

SRC_DIR="${1:-./yara}"
NEG_DIR="${2:-./tests/negative}"

# Flatten for the same reason as test-positive.sh - clamscan --database does not recurse.
RULE_DIR="$(mktemp -d)"
find "$SRC_DIR" -type f \( -name '*.yar' -o -name '*.yara' \) -exec cp {} "$RULE_DIR/" \;

echo "=== Negative (false-positive) tests (database: $RULE_DIR, flattened from $SRC_DIR) ==="
find "$NEG_DIR" -type f | while read -r file; do
    echo "Testing (expect NO DETECT): $file"
    result=$(clamscan --database="$RULE_DIR" --no-summary "$file" || true)
    echo "$result"
    if echo "$result" | grep -q "FOUND"; then
        echo "  FAIL: false positive on $file"
        exit 1
    fi
    echo "  PASS: clean"
done

echo "All negative tests passed."
