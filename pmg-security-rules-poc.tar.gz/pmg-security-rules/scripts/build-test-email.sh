#!/bin/bash
# Builds ready-to-send test .eml files carrying the PoC attachments, so you can
# push them through your actual PMG staging instance (not just bare clamscan).
#
# NOTE: per the design doc, the automated CI pipeline itself only tests
# attachments directly (no .eml corpus). These .eml files are for MANUAL
# staging validation of the full mail path - proving PMG actually intercepts
# the attachment in transit, not just that ClamAV/YARA can match the file.
set -euo pipefail

OUT_DIR="${1:-./dist/test-emails}"
FROM_ADDR="${2:-test-sender@example.com}"
TO_ADDR="${3:-test-recipient@example.com}"
mkdir -p "$OUT_DIR"

build_email () {
    local subject="$1" attachment_path="$2" attachment_name="$3" out_file="$4"
    local boundary="POC-BOUNDARY-$(date +%s)-$RANDOM"
    local b64
    b64=$(base64 -w0 "$attachment_path")

    {
        echo "From: ${FROM_ADDR}"
        echo "To: ${TO_ADDR}"
        echo "Subject: ${subject}"
        echo "MIME-Version: 1.0"
        echo "Content-Type: multipart/mixed; boundary=\"${boundary}\""
        echo
        echo "--${boundary}"
        echo "Content-Type: text/plain; charset=UTF-8"
        echo
        echo "This is a PoC test message for the PMG/ClamAV/YARA detection pipeline."
        echo
        echo "--${boundary}"
        echo "Content-Type: application/octet-stream; name=\"${attachment_name}\""
        echo "Content-Transfer-Encoding: base64"
        echo "Content-Disposition: attachment; filename=\"${attachment_name}\""
        echo
        echo "$b64"
        echo
        echo "--${boundary}--"
    } > "$out_file"

    echo "Built: $out_file"
}

build_email \
    "PoC test - malicious attachment (COMPANY_MALWARE_TEST)" \
    "./tests/positive/company_malware_test/sample01.bin" \
    "invoice_details.bin" \
    "${OUT_DIR}/malicious-test.eml"

build_email \
    "PoC test - EICAR antivirus test" \
    "./tests/eicar/eicar.com" \
    "eicar.com" \
    "${OUT_DIR}/eicar-test.eml"

build_email \
    "PoC test - clean attachment (should be delivered)" \
    "./tests/negative/clean/invoice.txt" \
    "invoice.txt" \
    "${OUT_DIR}/clean-test.eml"

cat << 'EOF'

Next steps on your PMG staging VM:
  1. Copy these .eml files to the PMG VM.
  2. Inject each into the mail queue, e.g.:
       sendmail -bs < malicious-test.eml     # via SMTP session, or
       cat malicious-test.eml | sendmail test-recipient@example.com
     (Adjust for your actual PMG relay/SMTP config and a real test domain
      PMG is configured to accept mail for.)
  3. Check PMG's quarantine / logs:
       tail -f /var/log/mail.log
       # or in the PMG web UI: Administration -> Quarantine -> Virus/Malware
  4. Expected outcome:
       malicious-test.eml -> quarantined, YARA.COMPANY_MALWARE_TEST.UNOFFICIAL
       eicar-test.eml     -> quarantined, Eicar-Test-Signature (or similar)
       clean-test.eml     -> delivered normally
EOF
